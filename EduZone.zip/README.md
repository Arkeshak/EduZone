
  # EduZone Frontend Development

  This is a code bundle for EduZone Frontend Development. The original project is available at https://www.figma.com/design/lmFjSlcVFAl4rHgXl1lUZm/EduZone-Frontend-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  