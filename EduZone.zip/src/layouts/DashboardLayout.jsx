import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { 
  Menu, 
  X, 
  Home, 
  LogOut, 
  User, 
  FileText, 
  Users, 
  DollarSign, 
  BarChart3,
  Bell
} from 'lucide-react';

const DashboardLayout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { role, logout, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getRoleNavigation = () => {
    switch (role) {
      case 'teacher':
        return [
          { name: 'Dashboard', path: '/teacher/dashboard', icon: Home },
          { name: 'Submit Request', path: '/teacher/submit-request', icon: FileText },
          { name: 'Track Requests', path: '/teacher/track-requests', icon: BarChart3 },
          { name: 'Upload Resource', path: '/teacher/upload-resource', icon: FileText },
          { name: 'View Circulars', path: '/teacher/circulars', icon: Bell },
          { name: 'Profile', path: '/teacher/profile', icon: User },
        ];
      case 'principal':
        return [
          { name: 'Dashboard', path: '/principal/dashboard', icon: Home },
          { name: 'Review Requests', path: '/principal/review-requests', icon: FileText },
          { name: 'Submit Report', path: '/principal/submit-report', icon: BarChart3 },
          { name: 'View Circulars', path: '/principal/circulars', icon: Bell },
          { name: 'Profile', path: '/principal/profile', icon: User },
        ];
      case 'zeo':
        return [
          { name: 'Dashboard', path: '/zeo/dashboard', icon: Home },
          { name: 'User Management', path: '/zeo/users', icon: Users },
          { name: 'Welfare Approval', path: '/zeo/welfare-approval', icon: FileText },
          { name: 'Donations', path: '/zeo/donations', icon: DollarSign },
          { name: 'Publish Circular', path: '/zeo/publish-circular', icon: Bell },
          { name: 'Resource Approval', path: '/zeo/resources', icon: FileText },
          { name: 'School Reports', path: '/zeo/reports', icon: BarChart3 },
          { name: 'Analytics', path: '/zeo/analytics', icon: BarChart3 },
        ];
      case 'donor':
        return [
          { name: 'Dashboard', path: '/donor/dashboard', icon: Home },
          { name: 'Browse Requests', path: '/donor/browse-requests', icon: FileText },
          { name: 'Make Donation', path: '/donor/make-donation', icon: DollarSign },
          { name: 'Track Donations', path: '/donor/track-donations', icon: BarChart3 },
          { name: 'Profile', path: '/donor/profile', icon: User },
        ];
      default:
        return [];
    }
  };

  const navigation = getRoleNavigation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar */}
      <div className={`fixed inset-0 bg-gray-600 bg-opacity-75 z-40 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`} onClick={() => setSidebarOpen(false)}></div>

      <div className={`fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200 z-50 transform transition-transform lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
          <h1 className="text-xl text-blue-600">EduZone</h1>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="px-4 py-6">
          <div className="mb-6">
            <p className="text-sm text-gray-500">Welcome,</p>
            <p className="font-semibold">{user?.name || 'User'}</p>
            <p className="text-xs text-gray-500 capitalize">{role}</p>
          </div>

          <nav className="space-y-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className="flex items-center px-4 py-2 text-sm rounded-md hover:bg-gray-100 text-gray-700"
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </Link>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-0 w-full p-4 border-t border-gray-200">
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-4 py-2 text-sm text-red-600 rounded-md hover:bg-red-50"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        <div className="sticky top-0 z-10 flex items-center h-16 px-4 bg-white border-b border-gray-200 lg:px-8">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden">
            <Menu className="w-6 h-6" />
          </button>
          <h2 className="ml-4 text-lg lg:ml-0">Hatton Zonal Education Office</h2>
        </div>

        <main className="p-4 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
