import DashboardLayout from '@/layouts/DashboardLayout';

const DonationManagement = () => {
  return <DashboardLayout><h1 className="text-2xl">Donation Management</h1></DashboardLayout>;
};

export default DonationManagement;
