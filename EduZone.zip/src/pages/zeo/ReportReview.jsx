import DashboardLayout from '@/layouts/DashboardLayout';

const ReportReview = () => {
  return <DashboardLayout><h1 className="text-2xl">Report Review</h1></DashboardLayout>;
};

export default ReportReview;
