import DashboardLayout from '@/layouts/DashboardLayout';

const PublishCircular = () => {
  return <DashboardLayout><h1 className="text-2xl">Publish Circular</h1></DashboardLayout>;
};

export default PublishCircular;
