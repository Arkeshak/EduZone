import DashboardLayout from '@/layouts/DashboardLayout';

const Analytics = () => {
  return <DashboardLayout><h1 className="text-2xl">Analytics</h1></DashboardLayout>;
};

export default Analytics;
