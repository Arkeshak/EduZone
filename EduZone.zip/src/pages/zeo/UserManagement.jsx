import DashboardLayout from '@/layouts/DashboardLayout';

const UserManagement = () => {
  return <DashboardLayout><h1 className="text-2xl">User Management</h1></DashboardLayout>;
};

export default UserManagement;
