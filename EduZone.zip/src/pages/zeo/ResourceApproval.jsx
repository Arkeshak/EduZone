import DashboardLayout from '@/layouts/DashboardLayout';

const ResourceApproval = () => {
  return <DashboardLayout><h1 className="text-2xl">Resource Approval</h1></DashboardLayout>;
};

export default ResourceApproval;
