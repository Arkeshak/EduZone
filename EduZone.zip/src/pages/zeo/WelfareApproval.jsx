import DashboardLayout from '@/layouts/DashboardLayout';

const WelfareApproval = () => {
  return <DashboardLayout><h1 className="text-2xl">Welfare Approval</h1></DashboardLayout>;
};

export default WelfareApproval;
