import { Link } from 'react-router-dom';
import { GraduationCap, Heart, FileText, Users } from 'lucide-react';

const Home = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <GraduationCap className="w-8 h-8 text-blue-600" />
              <span className="ml-2 text-xl text-blue-600">EduZone</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login" className="px-4 py-2 text-blue-600 hover:text-blue-700">
                Login
              </Link>
              <Link to="/donor/register" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                Register as Donor
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl mb-6">
            Hatton Zonal Education Management System
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Digitalizing welfare management, donation tracking, and school reporting for better education outcomes
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg mb-2">Welfare Management</h3>
            <p className="text-gray-600 text-sm">Submit and track student welfare requests efficiently</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <Heart className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg mb-2">Donation Tracking</h3>
            <p className="text-gray-600 text-sm">Connect donors with students in need</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg mb-2">Multi-School Management</h3>
            <p className="text-gray-600 text-sm">Manage multiple schools from one platform</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
              <GraduationCap className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="text-lg mb-2">Resource Sharing</h3>
            <p className="text-gray-600 text-sm">Share educational resources across schools</p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-2xl mb-8">Access the System</h2>
          <div className="flex justify-center gap-4">
            <Link to="/login" className="px-8 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              Login to Dashboard
            </Link>
          </div>
        </div>
      </div>

      <footer className="bg-gray-800 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-gray-400">© 2026 EduZone - Hatton Zonal Education Office. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
