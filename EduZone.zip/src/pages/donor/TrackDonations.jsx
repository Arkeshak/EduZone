import DashboardLayout from '@/layouts/DashboardLayout';

const TrackDonations = () => {
  return <DashboardLayout><h1 className="text-2xl">Track Donations</h1></DashboardLayout>;
};

export default TrackDonations;
