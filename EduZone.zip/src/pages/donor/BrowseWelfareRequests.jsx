import DashboardLayout from '@/layouts/DashboardLayout';

const BrowseWelfareRequests = () => {
  return <DashboardLayout><h1 className="text-2xl">Browse Welfare Requests</h1></DashboardLayout>;
};

export default BrowseWelfareRequests;
