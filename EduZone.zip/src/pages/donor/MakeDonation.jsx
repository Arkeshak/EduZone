import DashboardLayout from '@/layouts/DashboardLayout';

const MakeDonation = () => {
  return <DashboardLayout><h1 className="text-2xl">Make Donation</h1></DashboardLayout>;
};

export default MakeDonation;
