import DashboardLayout from '@/layouts/DashboardLayout';

const DonorProfile = () => {
  return <DashboardLayout><h1 className="text-2xl">My Profile</h1></DashboardLayout>;
};

export default DonorProfile;
