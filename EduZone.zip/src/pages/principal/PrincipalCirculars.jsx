import DashboardLayout from '@/layouts/DashboardLayout';

const PrincipalCirculars = () => {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-2xl mb-6">Circulars</h1>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-600">View all published circulars.</p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default PrincipalCirculars;
