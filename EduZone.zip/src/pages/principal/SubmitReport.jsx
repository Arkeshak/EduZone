import DashboardLayout from '@/layouts/DashboardLayout';

const SubmitReport = () => {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-2xl mb-6">Submit School Report</h1>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-600">Submit monthly school reports to the ZEO office.</p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default SubmitReport;
