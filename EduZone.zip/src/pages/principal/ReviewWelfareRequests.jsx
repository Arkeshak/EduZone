import DashboardLayout from '@/layouts/DashboardLayout';

const ReviewWelfareRequests = () => {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-2xl mb-6">Review Welfare Requests</h1>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-600">Review and approve/reject welfare requests from teachers.</p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default ReviewWelfareRequests;
