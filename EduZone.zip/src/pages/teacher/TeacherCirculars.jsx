import DashboardLayout from '@/layouts/DashboardLayout';

const TeacherCirculars = () => {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-2xl mb-6">Circulars</h1>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-600">View all published circulars from the ZEO office.</p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default TeacherCirculars;
