import DashboardLayout from '@/layouts/DashboardLayout';

const TeacherProfile = () => {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-2xl mb-6">My Profile</h1>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-600">View and update your profile information.</p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default TeacherProfile;
