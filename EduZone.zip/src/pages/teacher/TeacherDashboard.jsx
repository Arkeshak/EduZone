import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import DashboardLayout from '@/layouts/DashboardLayout';
import { FileText, CheckCircle, Clock, XCircle, TrendingUp } from 'lucide-react';
import LoadingSpinner from '@/components/LoadingSpinner';

const TeacherDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock data - Replace with API call
    setTimeout(() => {
      setStats({
        totalRequests: 12,
        pending: 5,
        approved: 6,
        rejected: 1,
      });
      setLoading(false);
    }, 500);
  }, []);

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl mb-2">Teacher Dashboard</h1>
          <p className="text-gray-600">Welcome back! Here's your welfare request overview.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <p className="text-2xl mb-1">{stats.totalRequests}</p>
            <p className="text-sm text-gray-600">Total Requests</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
            <p className="text-2xl mb-1">{stats.pending}</p>
            <p className="text-sm text-gray-600">Pending Approval</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <p className="text-2xl mb-1">{stats.approved}</p>
            <p className="text-sm text-gray-600">Approved</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <XCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
            <p className="text-2xl mb-1">{stats.rejected}</p>
            <p className="text-sm text-gray-600">Rejected</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-lg mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <Link 
                to="/teacher/submit-request"
                className="block p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:bg-blue-50 transition-colors"
              >
                <p className="font-medium">Submit New Welfare Request</p>
                <p className="text-sm text-gray-600">Create a new student welfare request</p>
              </Link>
              <Link 
                to="/teacher/upload-resource"
                className="block p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:bg-blue-50 transition-colors"
              >
                <p className="font-medium">Upload Study Resource</p>
                <p className="text-sm text-gray-600">Share educational materials</p>
              </Link>
              <Link 
                to="/teacher/track-requests"
                className="block p-4 border border-gray-200 rounded-md hover:border-blue-500 hover:bg-blue-50 transition-colors"
              >
                <p className="font-medium">Track My Requests</p>
                <p className="text-sm text-gray-600">View all submitted welfare requests</p>
              </Link>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-lg mb-4">Recent Notifications</h2>
            <div className="space-y-3">
              <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                <p className="text-sm text-green-800">Request #WR-2024-001 was approved by Principal</p>
                <p className="text-xs text-green-600 mt-1">2 hours ago</p>
              </div>
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                <p className="text-sm text-blue-800">New circular published: Monthly Report Submission</p>
                <p className="text-xs text-blue-600 mt-1">1 day ago</p>
              </div>
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                <p className="text-sm text-yellow-800">Request #WR-2024-003 pending Principal review</p>
                <p className="text-xs text-yellow-600 mt-1">3 days ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default TeacherDashboard;
