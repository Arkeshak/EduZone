import { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getToken, setToken as saveToken, removeToken, getUserRole, getUserInfo, isTokenValid } from '@/utils/tokenHelper';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing token on mount
    const token = getToken();
    if (token && isTokenValid()) {
      const userInfo = getUserInfo();
      const userRole = getUserRole();
      setUser(userInfo);
      setRole(userRole);
    }
    setLoading(false);
  }, []);

  const login = (token) => {
    saveToken(token);
    const userInfo = getUserInfo();
    const userRole = getUserRole();
    setUser(userInfo);
    setRole(userRole);
  };

  const logout = () => {
    removeToken();
    setUser(null);
    setRole(null);
  };

  const value = {
    user,
    role,
    loading,
    login,
    logout,
    isAuthenticated: !!user && !!role,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
